package com.project.ua.betIES.model;

import lombok.Data;
import javax.persistence.CascadeType;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;

@Entity
@Data
@Table(name = "Instrucoes")
public class Instrucoes {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private long id;

    @Column(name = "employeeName")
    private String employeeName;

    @Column(name = "instrucao", nullable = false)
    private String instrucao;

    @Column(name = "data", nullable = false)
    private String data;

    @Column(name = "estado", nullable = false)
    private String estado;

    public Instrucoes() {}

    public Instrucoes(String employeeName, String instrucao, String data) {
        this.employeeName = employeeName;
        this.instrucao = instrucao;
        this.data = data;
        this.estado = "Pendente";
    }

    public Instrucoes(String employeeName, String instrucao, String data, String estado) {
        this.employeeName = employeeName;
        this.instrucao = instrucao;
        this.data = data;
        this.estado = estado;
    }


    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getEmployeeName() {
        return this.employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getInstrucao() {
        return this.instrucao;
    }

    public void setInstrucao(String instrucao) {
        this.instrucao = instrucao;
    }

    public String getData() {
        return this.data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getEstado() {
        return this.estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", employee='" + getEmployeeName() + "'" +
            ", instrucao='" + getInstrucao() + "'" +
            ", data='" + getData() + "'" +
            ", estado='" + getEstado() + "'" +
            "}";
    }

}