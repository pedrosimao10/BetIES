package com.project.ua.betIES;

import java.util.List;

import com.project.ua.betIES.model.Desportos;
import com.project.ua.betIES.model.Employee;
import com.project.ua.betIES.model.Equipas;
import com.project.ua.betIES.model.Instrucoes;
import com.project.ua.betIES.model.User;
import com.project.ua.betIES.repository.DesportoRepository;
import com.project.ua.betIES.repository.EmployeeRepository;
import com.project.ua.betIES.repository.EquipasRepository;
import com.project.ua.betIES.repository.InstrucoesRepository;
import com.project.ua.betIES.repository.UserRepository;
import com.rabbitmq.client.Command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

@EnableJpaRepositories("com.project.ua.betIES.repository")
@SpringBootApplication
public class BetIesApplication implements CommandLineRunner{

	//private JdbcTemplate jbdctemplate;

	public static void main(String[] args) {
		SpringApplication.run(BetIesApplication.class, args);
	}

	//@Override
	//public void run(String... args) throws Exception {
	//	String sql = "SELECT * FROM  users";
	//	List<Users> users = jbdctemplate.query(sql, BeanPropertyRowMapper.newInstance(Users.class));
	//	users.forEach(System.out :: println);
		
	//}
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private DesportoRepository desportoRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private InstrucoesRepository instrucoesRepository;;


	public void run(String...args) throws Exception {
		User user = new User("user@beties.com", "user", 213125357, "User");
		userRepository.save(user);
		Employee employee = new Employee("employee@ua.pt", "passEmployee", "Afonso Rodrigues");
		Employee employee2 = new Employee("employee2@ua.pt", "passEmployee2", "Alexandre Pinto");
		Employee employee3 = new Employee("employee3@ua.pt", "passEmployee3", "Gonçalo Pereira");
		Employee employee4 = new Employee("employee4@ua.pt", "passEmployee4", "Pedro Jorge");
		employeeRepository.save(employee);
		employeeRepository.save(employee2);
		employeeRepository.save(employee3);
		employeeRepository.save(employee4);
		//Instrucoes instrucao = new Instrucoes(1, employee, "Adicionar jogo da Liga Portuguesa - Porto x Boavista", "24 jan 2022");
		//instrucoesRepository.save(instrucao);
	}
}
