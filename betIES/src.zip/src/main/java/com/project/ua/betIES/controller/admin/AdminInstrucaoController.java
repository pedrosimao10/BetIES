package com.project.ua.betIES.controller.admin;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.ObjectFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.ModelAttribute;
import java.util.List;
import com.project.ua.betIES.model.Instrucoes;
import com.project.ua.betIES.model.Employee;

import com.project.ua.betIES.service.InstrucoesService;
import com.project.ua.betIES.service.EmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "ua.betIES")
@Controller
public class AdminInstrucaoController {

    @Autowired
    ObjectFactory<HttpSession> SessionFactory;

    @Autowired
    private InstrucoesService instrucoesService ;

    @Autowired
    private EmployeeService employeeService ;

    @ModelAttribute("intrucaoForm")
    public Instrucoes getGreetingObject() {
      return new Instrucoes();
    }

    @GetMapping("admin/instrucao")
    public String getInstrucao(Model model) {
      HttpSession session = SessionFactory.getObject();
      model.addAttribute("name", session.getAttribute("name"));
      model.addAttribute("email", session.getAttribute("email"));

      List<Instrucoes> instrucoes = instrucoesService.getInstrucoes();
      model.addAttribute("instrucoes", instrucoes);

      List<Employee> employees = employeeService.getEmployees();
      model.addAttribute("employees", employees);
      return "admin/instrucao";
    }

    @PostMapping("admin/instrucao")
        public String submitForm(HttpServletRequest request){
          String employeeName = request.getParameter("employeeName");
          String instrucao = request.getParameter("instrucao");
          String data = request.getParameter("data");
          Instrucoes novaInstrucao = new Instrucoes(employeeName, instrucao, data);
          instrucoesService.saveInstrucoes(novaInstrucao);
          return "admin/conta";
        }
}
