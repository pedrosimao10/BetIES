package com.project.ua.betIES.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "Bet")
public class Bet {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private long id;
    
    @ManyToOne
    @JoinColumn(name = "userid", nullable = false)
    private User user;

    @Column(name = "jogo", nullable = false)
    private int jogo;

    @Column(name = "resultado", nullable = false)
    private int resultado;

    public Bet() {}

    public Bet(long id, User user, int jogo, int resultado) {
        this.id = id;
        this.user = user;
        this.jogo = jogo;
        this.resultado = resultado;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getJogo() {
        return jogo;
    }

    public void setJogo(int jogo) {
        this.jogo = jogo;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }

    @Override
    public String toString() {
        return "Bet [id=" + id + ", jogo=" + jogo + ", resultado=" + resultado + ", user=" + user + "]";
    }
    
}
