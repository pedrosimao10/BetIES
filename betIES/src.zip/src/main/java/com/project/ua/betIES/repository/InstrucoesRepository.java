package com.project.ua.betIES.repository;

import com.project.ua.betIES.model.Instrucoes;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InstrucoesRepository extends JpaRepository<Instrucoes, Long> {
}