package com.project.ua.betIES.model;

import lombok.Data;
import javax.persistence.*;

@Entity
@Data
@Table(name = "ligas")
public class Ligas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private long id;

    @Column(name = "nome", nullable = false)
    private String nome;

    @Column(name = "desporto", nullable = false)
    private int desporto;

    public Ligas(String nome, int desporto) {
        this.nome = nome;
        this.desporto = desporto;
    }

    public Ligas(){}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getDesporto() {
        return desporto;
    }

    public void setDesporto(int desporto) {
        this.desporto = desporto;
    }

    @Override
    public String toString() {
        return "Ligas [desporto=" + desporto + ", id=" + id + ", nome=" + nome + "]";
    }

    
}
