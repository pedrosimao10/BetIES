package com.project.ua.betIES.model;

import lombok.Data;

import java.util.Date;

import javax.persistence.*;

import com.project.ua.betIES.service.EquipasService;
import com.project.ua.betIES.model.Equipas;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Data
@Table(name = "jogos")
public class Jogos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private long id;

    @Column(name = "equipa1", nullable = false)
    private long equipa1;

    @Column(name = "equipa2", nullable = false)
    private long equipa2;

    @Column(name = "equipa1Nome", nullable = false)
    private String equipa1Nome;

    @Column(name = "equipa2Nome", nullable = false)
    private String equipa2Nome;

    @Column(name = "odd1", nullable = false)
    private double odd1;

    @Column(name = "odd2", nullable = false)
    private double odd2;

    @Column(name = "odd3", nullable = false)
    private double odd3;

    @Column(name = "hora", nullable = false)
    private Date hora;

    @Column(name = "acabou", nullable = false)
    private boolean acabou;

    @Column(name = "resultado", nullable = true)
    private int resultado;

    public Jogos(long equipa1, long equipa2, String equipa1Nome, String equipa2Nome, double odd1, double odd2, double odd3, Date hora, boolean acabou) {
        this.equipa1 = equipa1;
        this.equipa2 = equipa2;
        this.odd1 = odd1;
        this.odd2 = odd2;
        this.odd3 = odd3;
        this.hora = hora;
        this.acabou = acabou;
        this.equipa1Nome = equipa1Nome;
        this.equipa2Nome = equipa2Nome;
    }

    public Jogos() {}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getEquipa1() {
        return equipa1;
    }

    public void setEquipa1(long equipa1) {
        this.equipa1 = equipa1;
    }

    public long getEquipa2() {
        return equipa2;
    }

    public void setEquipa2(long equipa2) {
        this.equipa2 = equipa2;
    }

    public String getEquipa1Nome() {
        return equipa1Nome;
    }

    public void setEquipa1Nome(String equipa1Nome) {
        this.equipa1Nome = equipa1Nome;
    }

    public String getEquipa2Nome() {
        return equipa2Nome;
    }

    public void setEquipa2Nome(String equipa2Nome) {
        this.equipa2Nome = equipa2Nome;
    }

    public double getOdd1() {
        return odd1;
    }

    public void setOdd1(double odd1) {
        this.odd1 = odd1;
    }

    public double getOdd2() {
        return odd2;
    }

    public void setOdd2(double odd2) {
        this.odd2 = odd2;
    }

    public double getOdd3() {
        return odd3;
    }

    public void setOdd3(double odd3) {
        this.odd3 = odd3;
    }

    public Date getHora() {
        return hora;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }

    public boolean isAcabou() {
        return acabou;
    }

    public void setAcabou(boolean acabou) {
        this.acabou = acabou;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }
    
    

    @Override
    public String toString() {
        return "Jogos [acabou=" + acabou + ", equipa1=" + equipa1 + ", equipa2=" + equipa2 + ", hora=" + hora
                + ", odd1=" + odd1 + ", odd2=" + odd2 + ", odd3=" + odd3 + "]";
    }
    
}