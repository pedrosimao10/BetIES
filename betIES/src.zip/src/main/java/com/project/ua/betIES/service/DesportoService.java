package com.project.ua.betIES.service;

import com.project.ua.betIES.repository.DesportoRepository;
import com.project.ua.betIES.model.Desportos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DesportoService {
    @Autowired
    private DesportoRepository desportoRepository;
    
    public Desportos saveDesporto(Desportos desportos){
        return desportoRepository.save(desportos);
    }

    public List<Desportos> saveDesportos(List<Desportos> desportos) {
        return desportoRepository.saveAll(desportos);
    }

    public List<Desportos> getDesportos(){
        return desportoRepository.findAll();
    }

    public Desportos getDesportoById(Long id) {
        return desportoRepository.findById(id).orElse(null);
    }
}
