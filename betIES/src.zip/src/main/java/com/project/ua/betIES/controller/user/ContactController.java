package com.project.ua.betIES.controller.user;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.ObjectFactory;
import javax.servlet.http.HttpSession;  
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class ContactController {

    @Autowired
    ObjectFactory<HttpSession> SessionFactory;

    @GetMapping("user/contact")
    public String getContacts( Model model) {
      HttpSession session = SessionFactory.getObject();

      model.addAttribute("name", session.getAttribute("name"));
      model.addAttribute("email", session.getAttribute("email"));
      return "user/contact";
    } 
}
