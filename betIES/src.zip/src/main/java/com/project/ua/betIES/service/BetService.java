package com.project.ua.betIES.service;

import com.project.ua.betIES.repository.BetRepository;
import com.project.ua.betIES.model.Bet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BetService{
    @Autowired
    private BetRepository betRepository;
    
    public Bet saveBet(Bet bet){
        return betRepository.save(bet);
    }

    public List<Bet> saveBets(List<Bet> bets) {
        return betRepository.saveAll(bets);
    }

    public List<Bet> getBets(){
        return betRepository.findAll();
    }

    public Bet getBetById(Long id) {
        return betRepository.findById(id).orElse(null);
    }

}
