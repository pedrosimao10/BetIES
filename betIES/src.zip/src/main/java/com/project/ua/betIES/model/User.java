package com.project.ua.betIES.model;

import lombok.Data;

import java.util.Set;

import javax.persistence.*;


@Entity
@Data
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userId", nullable = false)
    private long id;

    @Column(name = "email", unique = true, nullable = false)
    private String email;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "nif", unique = true, nullable = false)
    private int nif;

    @Column(name = "name", nullable = false)
    private String name;
    
    @OneToMany(mappedBy="user")
    Set<Bet> bets;

    public User() {
    }

    public User(String email, String password, int nif, String name) {
        this.email = email;
        this.password = password;
        this.nif = nif;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getNif() {
        return nif;
    }

    public void setNif(int nif) {
        this.nif = nif;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User [email=" + email + ", id=" + id + ", name=" + name + ", nif="
                + nif + ", password=" + password + "]";
    }

    
}
