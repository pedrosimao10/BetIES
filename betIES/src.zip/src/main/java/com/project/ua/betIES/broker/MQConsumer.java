package com.project.ua.betIES.broker;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;


import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.project.ua.betIES.model.Desportos;
import com.project.ua.betIES.model.Equipas;
import com.project.ua.betIES.model.Ligas;
import com.project.ua.betIES.model.Jogos;

import com.project.ua.betIES.repository.LigasRepository;
import com.project.ua.betIES.service.DesportoService;
import com.project.ua.betIES.service.EquipasService;
import com.project.ua.betIES.service.LigasService;
import com.project.ua.betIES.service.JogosService;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;  
import org.json.simple.JSONValue;  

import java.lang.Math;
import java.math.BigDecimal;
import java.math.RoundingMode;

import com.project.ua.betIES.service.InstrucoesService;
import com.project.ua.betIES.model.Employee;
import com.project.ua.betIES.model.Instrucoes;

import java.util.Random;

public class MQConsumer {

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();
    
        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    @Autowired
    private DesportoService desportoService;

    @Autowired
    private LigasService ligaService;

    @Autowired
    private EquipasService equipaService;

    @Autowired
    private JogosService jogoService;

    @Autowired
    private InstrucoesService instrucoesService;


    @RabbitListener(queues = MQConfig.QUEUE)
    public void listen(String input) {
        Object obj=JSONValue.parse(input);  
        JSONObject jo = (JSONObject) obj; 
        
        String method = (String) jo.get("method");  

        if (method.equals("NEW_DESPORTO")) {
            System.out.println("NEW_DESPORTO");
            String desportoName = (String) jo.get("desporto");
            
            Desportos desporto = new Desportos(desportoName);
            desportoService.saveDesporto(desporto);
        }
        else if (method.equals("NEW_LIGA")) {
            System.out.println("NEW_LIGA");
            String ligaName = (String) jo.get("liga");
            Integer desporto = (int) (long) jo.get("desporto");

            Ligas liga = new Ligas(ligaName, desporto);
            ligaService.saveLiga(liga); 
        }
        else if (method.equals("NEW_EQUIPA")) {
            System.out.println("NEW_EQUIPA");
            //System.out.println((String)jo.toString());
            String equipaName = (String) jo.get("equipa");
            Integer desporto = (int) (long) jo.get("desporto");
            Integer liga = (int) (long) jo.get("liga");
            //System.out.println(equipaName + desporto + liga);

            Equipas equipa = new Equipas(equipaName, desporto, liga);
            equipaService.saveEquipa(equipa);
            //System.out.println(equipaService.getEquipasById(equipa.getId()));
        }
        else if (method.equals("NEW_JORNADA")) {
            System.out.println("NEW_JORNADA");
            JSONArray jogo = (JSONArray) jo.get("jogo");
            String liga = (String) jo.get("liga");

            String joHorario = (String) jo.get("horario");
            
            SimpleDateFormat textFormat = new SimpleDateFormat("yyyyMMdd hh:mm:ss");

            Date horario = new Date();

            try {
                horario = textFormat.parse(joHorario);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            JSONArray equipa1 = (JSONArray) jogo.get(0);
            String equipa1Name = (String) equipa1.get(0);
            double equipa1Odd = (Double) equipa1.get(1);

            double empateOdd = (Double) jogo.get(1);

            JSONArray equipa2 = (JSONArray) jogo.get(2);
            String equipa2Name = (String) equipa2.get(0);
            double equipa2Odd = (Double) equipa2.get(1);

            java.util.List<Equipas> equipasList = equipaService.getEquipas();

            long equipa1id = 0;
            long equipa2id = 0;

            for (int ind = 0; ind <equipasList.size(); ind++) {
                Equipas equipa = equipasList.get(ind);
                long ligaID = equipa.getLiga();
                String ligaName = ligaService.getLigaById(ligaID).getNome();
                String equipaName = equipa.getNome();

                if (ligaName.equals(liga)) {
                    if (equipaName.equals(equipa1Name)) {
                        equipa1id = equipa.getId();
                    }
                    else if (equipaName.equals(equipa2Name)) {
                        equipa2id = equipa.getId();
                    }
                } 
            }

            if (equipa1id != equipa2id){
                Jogos jogoAdd = new Jogos(equipa1id,equipa2id, equipa1Name, equipa2Name, equipa1Odd, empateOdd, equipa2Odd, horario, false);
                jogoService.saveJogo(jogoAdd);
            }
        }
        else if (method.equals("REFRESH")) {
            System.out.println("REFRESH");

            java.util.List<Jogos> jogosList = jogoService.getJogo();

            for (int ind=0; ind<jogosList.size(); ind++) {
                Jogos jogo = jogosList.get(ind);
                double odd1 = jogo.getOdd1();
                double odd2 = jogo.getOdd2();
                double odd3 = jogo.getOdd3();

                Date horario = jogo.getHora();
                
                SimpleDateFormat sdf = new SimpleDateFormat("EE MMM dd HH:mm:ss z yyyy");

                Date dataNow = new Date();
                
                boolean acabou = jogo.isAcabou();

                            
                // SimpleDateFormat textFormat = new SimpleDateFormat("yyyyMMdd hh:mm:ss");

                String johorario = (String) dataNow.toString();

                try {
                    dataNow = sdf.parse(johorario);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                if (jogo.isAcabou()){
                    jogoService.setJogoInfoResultado(odd1, odd2, odd3, acabou, jogo.getResultado(), jogo.getId());
                }
                else if (dataNow.after(horario)) {
                    acabou = true;
                    Random r = new Random();
                    int resultado = r.nextInt(3) + 1;
                    jogoService.setJogoInfoResultado(odd1, odd2, odd3, acabou, resultado, jogo.getId());
                    System.out.println(resultado);
                    System.out.println(dataNow);
                    System.out.println(horario);
                }
                else {
                    double rand = Math.random();
                    double randOdd = Math.random();
    
                    if (odd1<=1 || odd2<=1 || odd3<=1){
                        System.out.println("odd < 1");
                    }                
                    if (odd1 > 3 && odd3 > 3){
                        System.out.println("odds > 3");
                    }
    
                    double newOdd1 = 0;
                    double newOdd2 = 0;
                    double newOdd3 = 0;
    
                    if (odd1 > 2.8 && odd3 > 2.8) {
                        newOdd1 = round(odd1 - randOdd/40 , 2);
                        newOdd3 = round(odd3 - randOdd/40 , 2);
                    }
                    else if (odd1 < 1.05){
                        newOdd1 = round(odd1 + randOdd/40 , 2);
                        newOdd3 = round(odd3 - randOdd/40 , 2);
                    }
                    else if (odd3 < 1.05) {
                        newOdd1 = round(odd1 - randOdd/40 , 2);
                        newOdd3 = round(odd3 + randOdd/40 , 2);
                    }
                    else if (rand >= 0.5) {
                        newOdd1 = round(odd1 + randOdd/40 , 2);
                        newOdd3 = round(odd3 - randOdd/40 , 2);
                    }
                    else if (rand < 0.5) {
                        newOdd1 = round(odd1 - randOdd/40 , 2);
                        newOdd3 = round(odd3 + randOdd/40 , 2);
                    }
                    else {
                        System.out.println("\n\n\nn devia chegar aqui nnc\n\n\n");
                    }
    
                    if (odd2 < 1.05) {
                        newOdd2 = round(odd2 + randOdd/40, 2);
                    }
                    else if (rand > 0.5) {
                        newOdd2 = round(odd2 - randOdd/40, 2);
                    }
                    else {
                        newOdd2 = round(odd2 + randOdd/40, 2);
                    }
    
                    jogoService.setJogoInfo(newOdd1, newOdd2, newOdd3, acabou, jogo.getId());
    
                    System.out.println(jogo);
                }


            }
        }
        else if (method.equals("NEW_INSTRUCAO")){
            System.out.println("NEW_INSTRUCAO");

            String name = (String) jo.get("employeeName");
            String instrucao = (String) jo.get("instrucao");
            String data = (String) jo.get("data");
            String estado = (String) jo.get("estado");

            Instrucoes instrucoes = new Instrucoes(name, instrucao, data, estado);
            instrucoesService.saveInstrucoes(instrucoes);
        }
    }

}