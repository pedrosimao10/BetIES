package com.project.ua.betIES.service;
import com.project.ua.betIES.repository.HistoricoRepository;
import com.project.ua.betIES.model.Historico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class HistoricoService {

    @Autowired
    private HistoricoRepository historicoRepository;
    
    public Historico saveHistoricoBet(Historico historico){
        return historicoRepository.save(historico);
    }

    public List<Historico> saveHistoricosBet(List<Historico> historico) {
        return historicoRepository.saveAll(historico);
    }

    public List<Historico> getHistoricoBet(){
        return historicoRepository.findAll();
    }

    public Historico getHistoricoById(Long id) {
        return historicoRepository.findById(id).orElse(null);
    }
}
