package com.project.ua.betIES.model;

import lombok.Data;
import javax.persistence.*;
import javax.persistence.Id;
import javax.print.attribute.HashPrintJobAttributeSet;

@Entity
@Data
@Table(name = "historico")
public class Historico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private long id;

    @ManyToOne
    @JoinColumn(name = "userid", nullable = false)
    private User user;

    public Historico(User user) {
        this.user = user;
    }

    public Historico(){}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "Historico [id=" + id + ", user=" + user + "]";
    }
}
