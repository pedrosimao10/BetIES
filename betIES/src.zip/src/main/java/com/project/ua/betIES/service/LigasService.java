package com.project.ua.betIES.service;
import com.project.ua.betIES.repository.LigasRepository;
import com.project.ua.betIES.model.Ligas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LigasService {

    @Autowired
    private LigasRepository ligasRepository;
    
    public Ligas saveLiga(Ligas liga){
        return ligasRepository.save(liga);
    }

    public List<Ligas> saveLigas(List<Ligas> ligas) {
        return ligasRepository.saveAll(ligas);
    }

    public List<Ligas> getLiga(){
        return ligasRepository.findAll();
    }

    public Ligas getLigaById(Long id) {
        return ligasRepository.findById(id).orElse(null);
    }
}
