package com.project.ua.betIES.repository;

import java.util.List;

import com.project.ua.betIES.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}
