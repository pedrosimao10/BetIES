package com.project.ua.betIES.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import com.project.ua.betIES.model.User;
import com.project.ua.betIES.repository.UserRepository;

@Service
public class UserService{

    @Autowired
    private UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
   }

    public long total() { return userRepository.count();}


    public User saveUser(User client){
        return userRepository.save(client);
    }

    public List<User> saveUsers(List<User> clients) {
        return userRepository.saveAll(clients);
    }

    public List<User> getUsers(){
        return userRepository.findAll();
    }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public String deleteUser(Long id) {
        userRepository.deleteById(id);
        return "client removed !! " + id;
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }
}