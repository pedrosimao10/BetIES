package com.project.ua.betIES.controller.user;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.ObjectFactory;
import javax.servlet.http.HttpSession;  
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import com.project.ua.betIES.model.Equipas;
import com.project.ua.betIES.service.EquipasService;
import com.project.ua.betIES.service.LigasService;
import com.project.ua.betIES.service.JogosService;

import com.project.ua.betIES.model.Ligas;
import com.project.ua.betIES.model.Jogos;

@Controller
public class Futebol_AmericanoController {

    @Autowired
    ObjectFactory<HttpSession> SessionFactory;

    @Autowired
    private EquipasService equipasService;

    @Autowired
    private LigasService ligasService;

    @Autowired
    private JogosService jogosService;

    @GetMapping("user/futebol_americano")
    public String getFutebol_AmericanoUser( Model model) {
      HttpSession session = SessionFactory.getObject();
      model.addAttribute("name", session.getAttribute("name"));
      model.addAttribute("email", session.getAttribute("email"));

      List<Ligas> ligas = ligasService.getLiga();
      List<Jogos> jogos = jogosService.getJogo();
      List<Jogos> jogosNFL = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());
  
        long NFL = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("NFL")) {
            NFL = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == NFL && !jogos.get(ind).isAcabou()) {
          jogosNFL.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("NFL", jogosNFL);

      return "user/futebol_americano";
    } 
}
