package com.project.ua.betIES.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.beans.factory.annotation.Autowired;
import com.project.ua.betIES.model.User;
import com.project.ua.betIES.model.LoginInput;
import com.project.ua.betIES.service.UserService;
import java.io.*;  
import javax.servlet.*;  
import javax.servlet.http.*;  
import org.springframework.beans.factory.ObjectFactory;

import java.util.List;

import javax.servlet.http.HttpSession;  

import org.springframework.stereotype.Controller;

@Controller
@RequestMapping("/logout")
public class LogoutController {

  @RequestMapping(method=RequestMethod.POST)
  public String logout(HttpSession session) {
    session.invalidate();
    return "redirect:/user/user";
  }
}
