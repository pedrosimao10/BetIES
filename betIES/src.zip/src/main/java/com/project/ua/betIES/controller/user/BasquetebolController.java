package com.project.ua.betIES.controller.user;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.ObjectFactory;
import javax.servlet.http.HttpSession;  
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import com.project.ua.betIES.model.Equipas;
import com.project.ua.betIES.service.EquipasService;
import com.project.ua.betIES.service.LigasService;
import com.project.ua.betIES.service.JogosService;

import com.project.ua.betIES.model.Ligas;
import com.project.ua.betIES.model.Jogos;

@Controller
public class BasquetebolController {

    @Autowired
    ObjectFactory<HttpSession> SessionFactory;

    @Autowired
    private EquipasService equipasService;

    @Autowired
    private LigasService ligasService;

    @Autowired
    private JogosService jogosService;

    @GetMapping("user/basquetebol")
    public String getBAsquetebolUser( Model model) {
      HttpSession session = SessionFactory.getObject();
      model.addAttribute("name", session.getAttribute("name"));
      model.addAttribute("email", session.getAttribute("email"));

      List<Ligas> ligas = ligasService.getLiga();
      List<Jogos> jogos = jogosService.getJogo();

      List<Jogos> jogosNBA = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());
  
        long NBA = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("NBA")) {
            NBA = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == NBA && !jogos.get(ind).isAcabou()) {
          jogosNBA.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("NBA", jogosNBA);

      List<Jogos> jogosLEB = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());
  
        long LEB = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("Euroliga")) {
            LEB = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == LEB && !jogos.get(ind).isAcabou()) {
          jogosLEB.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("LEB", jogosLEB);

      List<Jogos> jogosLPB = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());
  
        long LPB = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("Liga Portuguesa")) {
            LPB = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == LPB && !jogos.get(ind).isAcabou()) {
          jogosLPB.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("LPB", jogosLPB);

      return "user/basquetebol";
    } 
}