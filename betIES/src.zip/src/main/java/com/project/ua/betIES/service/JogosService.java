package com.project.ua.betIES.service;
import com.project.ua.betIES.repository.JogosRepository;
import com.project.ua.betIES.model.Jogos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class JogosService {

    @Autowired
    private JogosRepository jogosRepository;
    
    public Jogos saveJogo(Jogos jogo){
        return jogosRepository.save(jogo);
    }

    public List<Jogos> saveJogos(List<Jogos> jogos) {
        return jogosRepository.saveAll(jogos);
    }

    public List<Jogos> getJogo(){
        return jogosRepository.findAll();
    }

    public Jogos getJogoById(Long id) {
        return jogosRepository.findById(id).orElse(null);
    }

    public void setJogoInfo(double odd1, double odd2, double odd3, boolean acabou, long id) {
        jogosRepository.setJogoInfoById(odd1, odd2, odd3, acabou, id);
    }

    public void setJogoInfoResultado(double odd1, double odd2, double odd3, boolean acabou, int resultado, long id) {
        jogosRepository.setJogoInfoByIdResultado(odd1, odd2, odd3, acabou, resultado, id);
    }
}