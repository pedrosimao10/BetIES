package com.project.ua.betIES.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.beans.factory.annotation.Autowired;
import com.project.ua.betIES.model.User;
import com.project.ua.betIES.model.LoginInput;
import com.project.ua.betIES.service.UserService;

import org.springframework.beans.factory.ObjectFactory;

import java.util.List;

import javax.servlet.http.HttpSession;  

import org.springframework.stereotype.Controller;

@Controller
public class LoginController {

  @Autowired
  private UserService userService;

  @Autowired
  ObjectFactory<HttpSession> httpSessionFactory;

  @ModelAttribute("LoginInput")
  public LoginInput getGreetingObject() {
    return new LoginInput();
  }

  @GetMapping("/login")
  public String getAskIdentifier(Model model) {
    return "login";
  }

  @PostMapping("/login")
  public String greetingSubmit(@ModelAttribute LoginInput inputLogin, Model model) {
    HttpSession session = httpSessionFactory.getObject();
    String email = inputLogin.getEmail();
    String password = inputLogin.getPassword();

    if (email == "" || password == "") {
      model.addAttribute("error", "All fields must be filled!");
      return "login";
    }

    User user = userService.getUserByEmail(email);

    
    if(user != null && (user.getPassword().equals(password))) {
      session.setAttribute("email", email);
      session.setAttribute("name", user.getName());
      model.addAttribute("name", user.getName());
      model.addAttribute("email", email);
      return "user/user";
    }

    model.addAttribute("error", "Email and/or password incorrect!");
    return "login";
  }
}
