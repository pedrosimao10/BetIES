package com.project.ua.betIES.controller.user;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.ObjectFactory;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.List;
import com.project.ua.betIES.model.Equipas;
import com.project.ua.betIES.service.EquipasService;
import com.project.ua.betIES.service.LigasService;
import com.project.ua.betIES.service.JogosService;
import com.project.ua.betIES.service.BetService;
import com.project.ua.betIES.model.Bet;

import com.project.ua.betIES.model.Ligas;
import com.project.ua.betIES.model.Jogos;

import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class FutebolController {

    @Autowired
    ObjectFactory<HttpSession> SessionFactory;

    @Autowired
    private EquipasService equipasService;

    @Autowired
    private LigasService ligasService;

    @Autowired
    private JogosService jogosService;

    @Autowired
    private BetService betService;



    @GetMapping("user/futebol")
    public String getFutebolUser( Model model) {
      HttpSession session = SessionFactory.getObject();
      model.addAttribute("name", session.getAttribute("name"));
      model.addAttribute("email", session.getAttribute("email"));

      List<Ligas> ligas = ligasService.getLiga();
      /*model.addAttribute("ligas", ligas);
      for (int ind = 0; ind<ligas.size(); ind++) {
        long tacaPt = ligas.get(ind).getNome().equals("Taça de Portugal");
        if (tacaPt) {
          model.addAttribute("TACA_PT", ligas.get(ind));
        }
      }*/

      List<Jogos> jogos = jogosService.getJogo();

      List<Jogos> jogosTacaPT = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());

        //Long longID = new Long(idLiga);
  
        long tacaPT = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("Taça de Portugal")) {
            tacaPT = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == tacaPT && !jogos.get(ind).isAcabou()) {
          jogosTacaPT.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("TACA_PT", jogosTacaPT);

      List<Jogos> jogosLigaPT = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());

        //Long longID = new Long(idLiga);
  
        long ligaPT = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("Liga Portugal")) {
            ligaPT = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == ligaPT && !jogos.get(ind).isAcabou()) {
          jogosLigaPT.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("LIGA_PT", jogosLigaPT);

      List<Jogos> jogosEFLCup = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());

        //Long longID = new Long(idLiga);
  
        long eflCup = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("FA Cup")) {
            eflCup = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == eflCup && !jogos.get(ind).isAcabou()) {
          jogosEFLCup.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("TACA_EFL", jogosEFLCup);

      List<Jogos> jogosLigaPL = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());

        //Long longID = new Long(idLiga);
  
        long ligaPL = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("Premier League")) {
            ligaPL = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == ligaPL && !jogos.get(ind).isAcabou()) {
          jogosLigaPL.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("LIGA_PL", jogosLigaPL);

      List<Jogos> jogosLigaEsp = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());

        //Long longID = new Long(idLiga);
  
        long ligaEsp = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("LaLiga")) {
            ligaEsp = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == ligaEsp && !jogos.get(ind).isAcabou()) {
          jogosLigaEsp.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("LIGA_ESP", jogosLigaEsp);

      List<Jogos> jogosLigaIta = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());

        //Long longID = new Long(idLiga);
  
        long ligaIta = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("Serie A")) {
            ligaIta = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == ligaIta && !jogos.get(ind).isAcabou()) {
          jogosLigaIta.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("LIGA_ITA", jogosLigaIta);

      List<Jogos> jogosLigaFra = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());

        //Long longID = new Long(idLiga);
  
        long ligaFra = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("Ligue 1")) {
            ligaFra = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == ligaFra && !jogos.get(ind).isAcabou()) {
          jogosLigaFra.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("LIGA_FRA", jogosLigaFra);

      List<Jogos> jogosBundesliga = new ArrayList<>();

      for (int ind = 0; ind<jogos.size(); ind++) {
        System.out.println(jogos.size() + "\njogos size\n");
        long idEquipa = jogos.get(ind).getEquipa1();
        Equipas equipa = equipasService.getEquipasById(idEquipa);

        Ligas liga = ligasService.getLigaById((long)equipa.getLiga());

        //Long longID = new Long(idLiga);
  
        long ligaBundesliga = 0;
        for (int ind2 = 0; ind2<ligas.size(); ind2++) {
          if (ligas.get(ind2).getNome().equals("Bundesliga")) {
            ligaBundesliga = ligas.get(ind2).getId();
          }
        }

        if (liga.getId() == ligaBundesliga && !jogos.get(ind).isAcabou()) {
          jogosBundesliga.add(jogos.get(ind));
          System.out.println(jogos.get(ind) + "\n jogo \n");
        }
      }
      model.addAttribute("LIGA_BUN", jogosBundesliga);

      long id = 5;
      Equipas equipa = equipasService.getEquipasById(id);
      model.addAttribute("equipa", equipa);

      List<Equipas> equipas = equipasService.getEquipas();
      model.addAttribute("equipas", equipas);

      return "user/futebol";
    }

    
    @PostMapping("user/futebol")
        public String submitForm(HttpServletRequest request){
          String equipa1Nome = request.getParameter("equipa1");
          String equipa2Nome = request.getParameter("equipa2");
          return "user/user";
        } 
}
