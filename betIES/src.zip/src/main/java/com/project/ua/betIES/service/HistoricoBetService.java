package com.project.ua.betIES.service;
import com.project.ua.betIES.repository.HistoricoBetRepository;
import com.project.ua.betIES.model.HistoricoBet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class HistoricoBetService {

    @Autowired
    private HistoricoBetRepository historicoBetRepository;
    
    public HistoricoBet saveHistoricoBet(HistoricoBet historicoBet){
        return historicoBetRepository.save(historicoBet);
    }

    public List<HistoricoBet> saveHistoricosBet(List<HistoricoBet> historicosBet) {
        return historicoBetRepository.saveAll(historicosBet);
    }

    public List<HistoricoBet> getHistoricoBet(){
        return historicoBetRepository.findAll();
    }
}
