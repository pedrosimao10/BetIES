package com.project.ua.betIES.controller.user;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.ObjectFactory;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.project.ua.betIES.model.Equipas;
import com.project.ua.betIES.service.EquipasService;

import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class UserController {

    @Autowired
    ObjectFactory<HttpSession> SessionFactory;

    @Autowired
    private EquipasService equipasService;

    @GetMapping("user/user")
    public String getUserDashboard( Model model) {
      HttpSession session = SessionFactory.getObject();

      Object name = session.getAttribute("name");
      Object email = session.getAttribute("email");

      model.addAttribute("name", name);
      model.addAttribute("email", email);
      //List<Equipas> equipas = equipasService.getEquipas();
      //Equipas equipa1 = equipas.get(3);
      //model.addAttribute("equipas", equipas);
      //model.addAttribute("equipa1", equipa1);
      return "user/user";
    } 
}
