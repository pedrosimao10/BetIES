package com.project.ua.betIES.service;

import com.project.ua.betIES.repository.EquipasRepository;
import com.project.ua.betIES.model.Equipas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EquipasService {

    @Autowired
    private EquipasRepository equipasRepository;
    
    public Equipas saveEquipa(Equipas equipas){
        return equipasRepository.save(equipas);
    }

    public List<Equipas> saveEquipas(List<Equipas> equipas) {
        return equipasRepository.saveAll(equipas);
    }

    public List<Equipas> getEquipas(){
        return equipasRepository.findAll();
    }

    public Equipas getEquipasById(Long id) {
        return equipasRepository.findById(id).orElse(null);
    }
}
