package com.project.ua.betIES.service;

import com.project.ua.betIES.repository.InstrucoesRepository;
import com.project.ua.betIES.model.Instrucoes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class InstrucoesService{
    @Autowired
    private InstrucoesRepository instrucoesRepository;
    
    public Instrucoes saveInstrucoes(Instrucoes instrucao){
        return instrucoesRepository.save(instrucao);
    }

    public List<Instrucoes> saveInstrucoes(List<Instrucoes> instrucoes) {
        return instrucoesRepository.saveAll(instrucoes);
    }

    public List<Instrucoes> getInstrucoes(){
        return instrucoesRepository.findAll();
    }

    public Instrucoes getInstrucoesById(Long id) {
        return instrucoesRepository.findById(id).orElse(null);
    }

}