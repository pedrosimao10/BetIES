package com.project.ua.betIES.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "historicoBet")
public class HistoricoBet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private long id;

    @ManyToOne
    @JoinColumn(name = "userid", nullable = false)
    private Historico historico;

    @Column(name = "bet", nullable = false)
    private int bet;

    public HistoricoBet(Historico historico, int bet) {
        this.historico = historico;
        this.bet = bet;
    }

    public HistoricoBet(){}

    public Historico getHistorico() {
        return historico;
    }

    public void setHistorico(Historico historico) {
        this.historico = historico;
    }

    public int getBet() {
        return bet;
    }

    public void setBet(int bet) {
        this.bet = bet;
    }

    @Override
    public String toString() {
        return "HistoricoBet [bet=" + bet + ", historico=" + historico + "]";
    }
}

