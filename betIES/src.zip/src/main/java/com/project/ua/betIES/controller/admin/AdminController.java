package com.project.ua.betIES.controller.admin;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.beans.factory.ObjectFactory;
import javax.servlet.http.HttpSession;
import java.util.List;

import com.project.ua.betIES.model.Employee;
import com.project.ua.betIES.model.User;
import com.project.ua.betIES.service.UserService;
import com.project.ua.betIES.service.EmployeeService;

import org.springframework.stereotype.Controller;

import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class AdminController {

    @Autowired
    ObjectFactory<HttpSession> SessionFactory;

    @Autowired
    private EmployeeService employeeService ;

    @GetMapping("admin/admin")
    public String getAdminDashboard( Model model) {
      HttpSession session = SessionFactory.getObject();
      model.addAttribute("name", session.getAttribute("name"));
      model.addAttribute("email", session.getAttribute("email"));
      List<Employee> employees = employeeService.getEmployees();
      model.addAttribute("employees", employees);
      return "admin/admin";
    } 
}
