package com.project.ua.betIES.model;

import lombok.Data;
import javax.persistence.*;

@Entity
@Data
@Table(name = "desportos")
public class Desportos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private long id;

    @Column(name = "nome", nullable = false)
    private String nome;

    public Desportos(String nome) {
        this.nome = nome;
    }

    public Desportos(){}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Desportos [id=" + id + ", nome=" + nome + "]";
    }

    
}
