package com.project.ua.betIES.repository;

import com.project.ua.betIES.model.Jogos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface JogosRepository extends JpaRepository<Jogos, Long> {
    @Modifying
    @Query(value = "update jogos jogo set jogo.odd1 = ?1, jogo.odd2 = ?2, jogo.odd3 = ?3, jogo.acabou = ?4 where jogo.id = ?5", nativeQuery = true)
    public void setJogoInfoById(double odd1, double odd2, double odd3, boolean acabou, long id);

    @Modifying
    @Query(value = "update jogos jogo set jogo.odd1 = ?1, jogo.odd2 = ?2, jogo.odd3 = ?3, jogo.acabou = ?4, jogo.resultado = ?5 where jogo.id = ?6", nativeQuery = true)
    public void setJogoInfoByIdResultado(double odd1, double odd2, double odd3, boolean acabou, int resultado, long id);
}