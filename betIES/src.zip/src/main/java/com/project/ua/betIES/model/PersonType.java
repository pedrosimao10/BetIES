package com.project.ua.betIES.model;

public enum PersonType {
    ADMIN, EMPLOYEE, USER
}
