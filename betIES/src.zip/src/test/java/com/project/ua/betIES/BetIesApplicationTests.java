package com.project.ua.betIES;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BetIesApplicationTests {

	@Test
	void contextLoads() {
	}

}
